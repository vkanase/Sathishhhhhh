package com.capgemini.core.btb.service;

import java.util.ArrayList;

import com.capgemini.core.btb.bean.BookingBean;
import com.capgemini.core.btb.bean.BusBean;
import com.capgemini.core.btb.dao.BusDAOImpl;
import com.capgemini.core.btb.dao.IBusDAO;
import com.capgemini.core.btb.exception.BookingException;

public class BusServiceImpl implements IBusService
{
	private IBusDAO busDAO;
	
	public BusServiceImpl()
	{
		busDAO = new BusDAOImpl();
	}

	@Override
	public ArrayList<BusBean> retrieveBusDetails()
	{
		// TODO Auto-generated method stub
		return busDAO.retrieveBusDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		return busDAO.bookTicket(bookingBean);
	}

	@Override
	public void updateBusDetails(BusBean busbean) throws BookingException {
		// TODO Auto-generated method stub
		busDAO.updateBusDetails(busbean);
	}

	


}
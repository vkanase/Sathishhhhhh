package com.capgemini.core.btb.service;

import java.util.ArrayList;

import com.capgemini.core.btb.bean.BookingBean;
import com.capgemini.core.btb.bean.BusBean;
import com.capgemini.core.btb.exception.BookingException;

public interface IBusService

{

	ArrayList<BusBean>retrieveBusDetails();

	int bookTicket(BookingBean bookingBean) throws BookingException;

	public void updateBusDetails(BusBean busbean) throws BookingException;

}
package com.capgemini.core.btb.bean;

public class BookingBean
{

	private int bookingId;
	private int noOfSeat;
	private int busId;
	private String custId;
	public int getBookingId() {

		return bookingId;
	}

	public void setBookingId(int bookingId) {

		this.bookingId = bookingId;
	}

	public int getNoOfSeat() {

		return noOfSeat;
	}

	public void setNoOfSeat(int noOfSeat) {

		this.noOfSeat = noOfSeat;
	}

	public int getBusId() {

		return busId;
	}

	public void setBusId(int busId) {

		this.busId = busId;
	}

	public String getCustId() {

		return custId;
	}

	public void setCustId(String custId) {

		this.custId = custId;
	}

	public BookingBean(int bookingId, int noOfSeat, int busId, String custId) {

		super();
		this.bookingId = bookingId;
		this.noOfSeat = noOfSeat;
		this.busId = busId;
		this.custId = custId;
	}

	public BookingBean() {

		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {

		return "BookingBean [bookingId=" + bookingId + ", noOfSeat=" + noOfSeat
				+ ", busId=" + busId + ", custId=" + custId + "]";
	}

	@Override
	public int hashCode() {

		final int prime = 31;
		int result = 1;
		result = prime * result + bookingId;
		result = prime * result + busId;
		result = prime * result + ((custId == null) ? 0 : custId.hashCode());
		result = prime * result + noOfSeat;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		BookingBean other = (BookingBean) obj;
		if (bookingId != other.bookingId)
			return false;
		if (busId != other.busId)
			return false;
		if (custId == null) {
			
			if (other.custId != null)
				return false;

		} else if (!custId.equals(other.custId))

			return false;
		if (noOfSeat != other.noOfSeat)
			return false;
		return true;

	}

}

package com.capgemini.core.btb.bean;

import java.sql.Date;

public class BusBean
{

	private int busId;
	private String busType;
	private Date dateOfJourney;
	private String fromStop;
	private String toStop;
	private int availableSeats;
	private int fare;
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public Date getDateOfJourney() {
		return dateOfJourney;
	}
	public void setDateOfJourney(Date dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}
	public String getFromStop() {
		return fromStop;
	}
	public void setFromStop(String fromStop) {
		this.fromStop = fromStop;
	}
	public String getToStop() {
		return toStop;
	}
	public void setToStop(String toStop) {
		this.toStop = toStop;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public BusBean(int busId, String busType, Date dateOfJourney,
			String fromStop, String toStop, int availableSeats, int fare) {
		super();
		this.busId = busId;
		this.busType = busType;
		this.dateOfJourney = dateOfJourney;
		this.fromStop = fromStop;
		this.toStop = toStop;
		this.availableSeats = availableSeats;
		this.fare = fare;
	}
	public BusBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BusBean [busId=" + busId + ", busType=" + busType
				+ ", dateOfJourney=" + dateOfJourney + ", fromStop=" + fromStop
				+ ", toStop=" + toStop + ", availableSeats=" + availableSeats
				+ ", fare=" + fare + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + availableSeats;
		result = prime * result + busId;
		result = prime * result + ((busType == null) ? 0 : busType.hashCode());
		result = prime * result
				+ ((dateOfJourney == null) ? 0 : dateOfJourney.hashCode());
		result = prime * result + fare;
		result = prime * result
				+ ((fromStop == null) ? 0 : fromStop.hashCode());
		result = prime * result + ((toStop == null) ? 0 : toStop.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BusBean other = (BusBean) obj;
		if (availableSeats != other.availableSeats)
			return false;
		if (busId != other.busId)
			return false;
		if (busType == null) {
			if (other.busType != null)
				return false;
		} else if (!busType.equals(other.busType))
			return false;
		if (dateOfJourney == null) {
			if (other.dateOfJourney != null)
				return false;
		} else if (!dateOfJourney.equals(other.dateOfJourney))
			return false;
		if (fare != other.fare)
			return false;
		if (fromStop == null) {
			if (other.fromStop != null)
				return false;
		} else if (!fromStop.equals(other.fromStop))
			return false;
		if (toStop == null) {
			if (other.toStop != null)
				return false;
		} else if (!toStop.equals(other.toStop))
			return false;
		return true;
	}
	
}


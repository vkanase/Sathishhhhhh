package com.capgemini.core.btb.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.capgemini.core.btb.bean.BookingBean;
import com.capgemini.core.btb.bean.BusBean;
import com.capgemini.core.btb.exception.BookingException;
import com.capgemini.core.btb.service.BusServiceImpl;
import com.capgemini.core.btb.service.IBusService;


public class MainClient

{

	private IBusService busService;

	public MainClient()

	{

		busService = new BusServiceImpl();

	}

	public static void main(String[] args)

	{

		MainClient bookUI = new MainClient();

		while (true)

		{

			bookUI.viewMenu();

		}

	}

	public void viewMenu()

	{

		Scanner sc = new Scanner(System.in);

		System.out.println("Please See The Bus Details Below");

		getBusDetails();

		System.out.println("Enter Your Choice");

		System.out.println("1) Book Ticket");

		System.out.println("2) Exit");

		int choice = sc.nextInt();

		switch (choice)

		{

		case 1: bookTickets();

		break;

		case 2:System.out.println("ThankYou ! Exiting App...");

		System.exit(0);
		
		break;

		default:System.out.println("Invalid Input");

		break;

		}

	}

	private void bookTickets()

	{

		Scanner sc = new Scanner(System.in);

		System.out.println("Please Provide The Following Information");

		System.out.println("Enter Customer Id");

		String custId = sc.next();

		System.out.println("Please Enter The Bus Id");

		int busId = sc.nextInt();

		System.out.println("Please Enter The Number Of Seats");

		int noOfSeat = sc.nextInt();

		BookingBean bookbean = new BookingBean();

		bookbean.setCustId(custId);

		bookbean.setBusId(busId);

		bookbean.setNoOfSeat(noOfSeat);

		try

		{

			int bookingId = busService.bookTicket(bookbean);

			System.out.println("Your Booking Id Is "+bookingId+" Thank You, Visit Again");

		}

		catch(BookingException e)

		{

			throw new BookingException(e.getMessage());

		}

		catch(Exception e)

		{

			throw new BookingException(e.getMessage());

		}

	}

	private void getBusDetails()

	{

		
		
		try

		{

			ArrayList<BusBean> busbean= busService.retrieveBusDetails();

			Iterator<BusBean> it = busbean.iterator();

			System.out.println("BusId \tBusType \tFromStop ToStop AvailableSeats \t Fare DateOfJourney");

			while (it.hasNext())

			{

				BusBean busbean2 = it.next();

				System.out.println(busbean2.getBusId()+"\t"+busbean2.getBusType()+"\t"+busbean2.getFromStop()+"\t"+busbean2.getToStop()+"\t"+busbean2.getAvailableSeats()+"\t\t"+busbean2.getFare()+"\t"+busbean2.getDateOfJourney());

			}

	}

		catch(BookingException e)

		{

			throw new BookingException(e.getMessage());

		}

		catch(Exception e)

		{

			throw new BookingException(e.getMessage());

		}

	}

}
package com.capgemini.core.btb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.core.btb.bean.BookingBean;
import com.capgemini.core.btb.bean.BusBean;
import com.capgemini.core.btb.exception.BookingException;
import com.capgemini.core.btb.util.DBUtil;

public class BusDAOImpl implements IBusDAO {

	static Logger myLogger;


	public BusDAOImpl()
	{
		PropertyConfigurator.configure("log4j.properties");
		myLogger = Logger.getLogger(BusDAOImpl.class.getName());
	}

	@Override

	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {
		
		ArrayList<BusBean> BusDetails = new ArrayList<BusBean>();
		// TODO Auto-generated method stub
		try(Connection con = DBUtil.getConnection())
		{
			
			Statement stm = con.createStatement();
			
			ResultSet res = stm.executeQuery("select * from BusDetails");
			while(res.next())
			{

				BusBean bean = new BusBean();
				bean.setBusId(res.getInt("busId"));
				bean.setBusType(res.getString("busType"));
				bean.setFromStop(res.getString("fromStop"));
				bean.setToStop(res.getString("toStop"));
				bean.setAvailableSeats(res.getInt("availableSeats"));
				bean.setFare(res.getInt("fare"));
				bean.setDateOfJourney(res.getDate("dateOfJourney"));
				BusDetails.add(bean);
				
				myLogger.info("Bus added successfull");
			}
		}
		catch(SQLException e)

		{

			e.printStackTrace();
	throw new BookingException(e.getMessage());
		}

		catch(Exception e)
		{

			e.printStackTrace();
			throw new BookingException(e.getMessage());
		}

		return (ArrayList<BusBean>) BusDetails;
	}
	@Override
	public int bookTicket(BookingBean bookingbean) throws BookingException {

		int generatedId = -1;
		try(Connection con = DBUtil.getConnection())
		{

			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery(" select Booking_id_seq.nextVal from dual");
			if(res.next() == false)
				throw new BookingException("Something went wrong");
			int bookingId = 1;
			String custId = bookingbean.getCustId();
			int busId = bookingbean.getBusId();
			int noOfSeats = bookingbean.getNoOfSeat();
			
			PreparedStatement pstm = con.prepareStatement("insert into BookingDetails values(?,?,?,?)");
			
			pstm.setInt(1, bookingId);
			pstm.setString(2,custId );
			pstm.setInt(3, busId);
			pstm.setInt(4, noOfSeats);
			pstm.execute();
			generatedId = bookingId;

			myLogger.info("Details added successful");
		}

		catch (SQLException e)
		{

			e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new BookingException(e.getMessage());

		}
		catch(Exception e)
		{

			throw new BookingException(e.getMessage());
		}

		return generatedId;
	}

	@Override
	public void updateBusDetails(BusBean busbean) throws BookingException {
		// TODO Auto-generated method stub
		
	}
}

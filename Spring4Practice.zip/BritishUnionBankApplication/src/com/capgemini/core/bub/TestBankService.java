package com.capgemini.core.bub;

public class TestBankService {

}

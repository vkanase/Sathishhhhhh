package com.capgemini.core.bub.dao;

import com.capgemini.core.bub.bean.Bank;
import com.capgemini.core.bub.exception.BankException;

public interface IBankDAO {
	
public int addCustomer(Bank bnk) throws BankException;
	
	public Bank getCustomer(int id) throws BankException;
	
	public Bank removeCustomer(int id) throws BankException;
	

}

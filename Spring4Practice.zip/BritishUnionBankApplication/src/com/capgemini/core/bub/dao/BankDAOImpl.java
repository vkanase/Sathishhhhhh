package com.capgemini.core.bub.dao;

import java.sql.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.core.bub.bean.Bank;
import com.capgemini.core.bub.exception.BankException;
import com.capgemini.core.bub.util.DBUtil;




public class BankDAOImpl implements IBankDAO
{
static Logger myLogger;
	
	public BankDAOImpl()
	{
		PropertyConfigurator.configure("log4j.properties");
		myLogger = Logger.getLogger(BankDAOImpl.class.getName());
	}

	@Override
	public int addCustomer(Bank bnk) throws BankException {
		int generatedId = -1;
		try(Connection con = DBUtil.getConnection()) //Connection will be auto closed
		{
			Statement stm = con.createStatement();
			
			ResultSet res = stm.executeQuery("Select plrIdSeq.nextVal from dual");
			
			if (res.next() == false)
				
				throw new BankException("Something went wrong while generating sequence");
			
			int custid = res.getInt(1);
			String name = bnk.getName();
			int actid = bnk.getActid();
			String bname = bnk.getBranchname();
			int age = bnk.getAge();
			String occu = bnk.getOccupation();
			String ltype = bnk.getLoantype();
			Double lamount = bnk.getLoanamount();
			Date sd = bnk.getStartdate();
			Date ed = bnk.getEnddate();
			
			PreparedStatement pstm = con.prepareStatement("insert into bank values(?,?,?,?,?,?,?,?,?,?)");

			pstm.setInt(1,  custid);
			
			pstm.setString(2,  name);
			
			pstm.setInt(3,  actid);
			
			pstm.setString(4,  bname);
			
			pstm.setInt(5,  age);
			
			pstm.setString(6,  occu);
			
			pstm.setString(7,  ltype);
			
			pstm.setDouble(8,  lamount);
			
			pstm.setDate(9,  sd);
			
			pstm.setDate(10,  ed);
			
			pstm.execute();
			
			generatedId = actid;
			
			//???????LOGGING???????
			
			myLogger.info("Customer Added Successfully");
			
		}

		catch(SQLException e)

		{

			e.printStackTrace();
			
			myLogger.error(e.getMessage());

			throw new BankException(e.getMessage());

		}

		catch(Exception e)

		{
			
			throw new BankException(e.getMessage());

		}

		return generatedId;
		
	}

	@Override
	public Bank getCustomer(int id) throws BankException {
		
		Bank bnk = null;
		
		try(Connection con = DBUtil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("select * from bank where id =?");

			pstm.setInt(1,id);

			ResultSet res = pstm.executeQuery();

			if(res.next() == false)

			{

				throw new BankException("No Customer Found With Id"+id);
			}
			
			bnk = new Bank();

			bnk.setCustid(res.getInt("custid"));

			bnk.setName(res.getString("name"));
			
			bnk.setActid(res.getInt("actid"));

			bnk.setBranchname(res.getString("branchname"));

			bnk.setAge(res.getInt("age"));

			bnk.setOccupation(res.getString("occupation"));
			
			bnk.setLoantype(res.getString("loantype"));
			
			bnk.setLoanamount(res.getDouble("loanamount"));
			
			bnk.setStartdate(res.getDate("startdate"));
			
			bnk.setEnddate(res.getDate("enddate"));
			
			myLogger.info("Customer Details shown Successfully");

			
		}

		catch(SQLException e)

		{

			e.printStackTrace();
			
			myLogger.error(e.getMessage());

			throw new BankException(e.getMessage());

		}

		catch(Exception e)

		{

			e.printStackTrace();

			throw new BankException(e.getMessage());

		}

		return bnk;

	}
			


	@Override
	public Bank removeCustomer(int id) throws BankException {
		Bank bnk = null;
		
		try(Connection con = DBUtil.getConnection() )
		{
			
				bnk = getCustomer(id);
				
				if( bnk == null)
				{
					throw new BankException("No Customer found with id " + id);
				}
				 PreparedStatement pstm = con.prepareStatement("delete from Customer where id=?");
				
				pstm.setInt(1,id);
				
				pstm.execute();
				
				myLogger.info("Customer remove Successfully");
				
		}
			
				catch (SQLException e)
				{
					e.printStackTrace();
					
					myLogger.error(e.getMessage());
					throw new BankException( e.getMessage() );
					
				}
				catch (Exception e)
				{
					e.printStackTrace();
					throw new BankException( e.getMessage() );
					
				}
			

				return bnk;

		}
		
		
	}



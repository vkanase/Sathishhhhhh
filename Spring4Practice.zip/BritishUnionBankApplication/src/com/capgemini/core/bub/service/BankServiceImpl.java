package com.capgemini.core.bub.service;

public class BankServiceImpl {

}

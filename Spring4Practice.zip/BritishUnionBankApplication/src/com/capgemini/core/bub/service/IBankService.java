package com.capgemini.core.bub.service;

import com.capgemini.core.bub.bean.Bank;
import com.capgemini.core.bub.exception.BankException;


public interface IBankService {
	
	public int addCustomer(Bank bnk) throws BankException;
	
	public Bank getCustomer(int id) throws BankException;
	
	public Bank removeCustomer(int id) throws BankException;
	


}

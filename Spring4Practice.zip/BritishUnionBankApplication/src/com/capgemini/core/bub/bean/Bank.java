package com.capgemini.core.bub.bean;

import java.sql.Date;

public class Bank {
	private int custid;
	private String name;
	private int actid;
	private String branchname;
	private int age;
	private String occupation;
	private String loantype;
	private double loanamount;
	private Date startdate;
	private Date enddate;
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getActid() {
		return actid;
	}
	public void setActid(int actid) {
		this.actid = actid;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getLoantype() {
		return loantype;
	}
	public void setLoantype(String loantype) {
		this.loantype = loantype;
	}
	public double getLoanamount() {
		return loanamount;
	}
	public void setLoanamount(double loanamount) {
		this.loanamount = loanamount;
	}
	public Date getStartdate() {
		return startdate;
	}
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}
	public Date getEnddate() {
		return enddate;
	}
	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}
	public Bank(int custid, String name, int actid, String branchname, int age,
			String occupation, String loantype, double loanamount,
			Date startdate, Date enddate) {
		super();
		this.custid = custid;
		this.name = name;
		this.actid = actid;
		this.branchname = branchname;
		this.age = age;
		this.occupation = occupation;
		this.loantype = loantype;
		this.loanamount = loanamount;
		this.startdate = startdate;
		this.enddate = enddate;
	}
	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + actid;
		result = prime * result + age;
		result = prime * result
				+ ((branchname == null) ? 0 : branchname.hashCode());
		result = prime * result + custid;
		result = prime * result + ((enddate == null) ? 0 : enddate.hashCode());
		long temp;
		temp = Double.doubleToLongBits(loanamount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result
				+ ((loantype == null) ? 0 : loantype.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result
				+ ((occupation == null) ? 0 : occupation.hashCode());
		result = prime * result
				+ ((startdate == null) ? 0 : startdate.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bank other = (Bank) obj;
		if (actid != other.actid)
			return false;
		if (age != other.age)
			return false;
		if (branchname == null) {
			if (other.branchname != null)
				return false;
		} else if (!branchname.equals(other.branchname))
			return false;
		if (custid != other.custid)
			return false;
		if (enddate == null) {
			if (other.enddate != null)
				return false;
		} else if (!enddate.equals(other.enddate))
			return false;
		if (Double.doubleToLongBits(loanamount) != Double
				.doubleToLongBits(other.loanamount))
			return false;
		if (loantype == null) {
			if (other.loantype != null)
				return false;
		} else if (!loantype.equals(other.loantype))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (occupation == null) {
			if (other.occupation != null)
				return false;
		} else if (!occupation.equals(other.occupation))
			return false;
		if (startdate == null) {
			if (other.startdate != null)
				return false;
		} else if (!startdate.equals(other.startdate))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Bank [custid=" + custid + ", name=" + name + ", actid=" + actid
				+ ", branchname=" + branchname + ", age=" + age
				+ ", occupation=" + occupation + ", loantype=" + loantype
				+ ", loanamount=" + loanamount + ", startdate=" + startdate
				+ ", enddate=" + enddate + "]";
	}
	
}
	
	
	
	
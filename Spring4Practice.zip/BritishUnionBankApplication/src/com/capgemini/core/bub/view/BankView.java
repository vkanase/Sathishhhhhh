package com.capgemini.core.bub.view;

import java.util.Scanner;

import com.capgemini.core.bub.service.BankServiceImpl;

public class BankView 
{
	private BankServiceImpl IBankService;

	public BankView()

	{

		IBankService = new BankServiceImpl();

	}

	public static void main(String[] args)

	{

	BankView ubUI = new BankView();

	while(true)

	{

	ubUI.showMenu();

	}

	}

	public void showMenu()

	{

	Scanner sc = new Scanner(System.in);

	System.out.println("1) Add Customer");

	System.out.println("2) Get Customer Record");

	System.out.println("3) Remove Customer Record");

	System.out.println("4) Exit Application");

	System.out.println("Enter Your Choice");

	int choice = sc.nextInt();

	switch (choice)

	{

	case 1:addCustomer(); break;

	case 2:getCustomer();	break;

	case 3:removeCustomer(); break;

	case 4: System.out.println("Thank You ! Exiting Application....."); break;

	default: System.out.println("Invalid Input");	break;

	}

	}

	private void addCustomer()

	{

	Scanner scn = new Scanner(System.in);

	System.out.println("Provide Customer Information");

	System.out.println(" Customer Name");

	String name = scn.next();

	System.out.println("Customer Account Id");

	int accntid = scn.nextInt();

	System.out.println("Branch Name");

	String branchname = scn.next();

	System.out.println("Age");

	int age = scn.nextInt();

	System.out.println("Occupation");

	String occupation = scn.next();

	System.out.println("Enter Date Of Birth");

	String dob = scn.next();

	System.out.println("Country Playing For");

	String cnt = scn.next();

	System.out.println("Batting Style");

	String bs = scn.next();

	System.out.println("Number Of Centuries");

	int cent = scn.nextInt();

	System.out.println("Number Of Matches Played");

	int nom = scn.nextInt();

	System.out.println("Total Runs Of Career");

	int total = scn.nextInt();

	}

	private void getCustomer() {

	// TODO Auto-generated method stub

	}

	private void removeCustomer() {

	// TODO Auto-generated method stub

	}

	}



create table Bank(Customer_Id number(5),
Customer_Name varchar2(30),
Customer_AccountId number,
Branch_Name varchar2(25),
Customer_Age number,
Occupation varchar2(35),
Loan_Type varchar2(20),
Loan_Amount number,
Start_Date Date,
End_Date Date,
primary key (Customer_Id)
);


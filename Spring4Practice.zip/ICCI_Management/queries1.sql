create table Cricket(Player_Id number,Player_Name varchar2(30),Date_Of_Birth DATE,Country varchar2(20),Batting_Style varchar2(30),No_Of_Centuries number(3),No_Of_Matches_Played number(5),Total_Runs number(7),primary key(Player_Id));

select * from cricket;
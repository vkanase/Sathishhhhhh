package com.capgemini.core.ems.dao;

import java.util.List;

import com.capgemini.core.ems.bean.Cricket;
import com.capgemini.core.ems.exception.CricketException;

public interface ICricketDAO 
{
	public int addPlayers(Cricket ckt)  throws CricketException;	
	public void updatePlayers(Cricket ckt)  throws CricketException;	
	public List<Cricket> showPlayers()  throws CricketException;
	public Cricket getPlayer(int id)  throws CricketException;


}

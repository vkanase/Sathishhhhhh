package com.capgemini.core.ems.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.capgemini.core.ems.bean.Cricket;
import com.capgemini.core.ems.exception.CricketException;
import com.capgemini.core.ems.util.DBUtil;

public class CricketDAOImpl implements ICricketDAO
{
	
	@Override
	public int addPlayers(Cricket ckt) throws CricketException {
		int generatedId = -1;
		try(Connection con = DBUtil.getConnection()) //Connection will be auto closed
		{
			Statement stm = con.createStatement();
			
			ResultSet res = stm.executeQuery("Select plrIdSeq.nextVal from dual");
			
			if (res.next() == false)
				
				throw new CricketException("Something went wrong while generating sequence");
			
			int id = res.getInt(1);	
			String name = ckt.getName();
			Date date = ckt.getDate();
			String country = ckt.getCountry();
			String battingStyle = ckt.getBattingStle();
			int noc = ckt.getNoc();
			int nom = ckt.getNom();
			int runs = ckt.getRunScore();
			
			PreparedStatement pstm = con.prepareStatement("insert into Cricket values(?,?,?,?,?,?,?,?)");
			
			pstm.setInt(1, id);
			pstm.setString(2, name);
			pstm.setDate(3, date);
			pstm.setString(4, country);
			pstm.setString(5, battingStyle);
			pstm.setInt(6, noc);
			pstm.setInt(7, nom);
			pstm.setInt(8, runs);
			
			pstm.execute();
			
			generatedId = id;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new CricketException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new CricketException(e.getMessage());
		}
		return generatedId;
	}
	
	@Override
	public void updatePlayers(Cricket crkt) throws CricketException
	{
		try(Connection con = DBUtil.getConnection())
		{
			int id = crkt.getId();
			String name = crkt.getName();
			Date date = crkt.getDate();
			String country = crkt.getCountry();
			String battingStyle = crkt.getBattingStle();
			int noc = crkt.getNoc();
			int nom = crkt.getNom();
			int runs = crkt.getRunScore();
			
			PreparedStatement pstm = con.prepareStatement
					("update Cricket set PLAYER_NAME=?,DATE_OF_BIRTH=?,COUNTRY=?,BATTING_STYLE=?,NO_OF_CENTURIES=?,"
							+ "NO_OF_MATCHES_PLAYED=?,TOTAL_RUNS=? where PLAYER_ID =?");
			pstm.setInt(1, id);
			pstm.setString(2, name);
			pstm.setDate(3, date);
			pstm.setString(4, country);
			pstm.setString(5, battingStyle);
			pstm.setInt(6, noc);
			pstm.setInt(7, nom);
			pstm.setInt(8, runs);
			pstm.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new CricketException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new CricketException(e.getMessage());
		}
	}
	@Override
	public List<Cricket> showPlayers() throws CricketException
	{
		List<Cricket> showPlayers = new ArrayList<Cricket>();
		
		try(Connection con = DBUtil.getConnection())
		{
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select * from icci");
			while(res.next())
			{
				Cricket ckt = new Cricket();
				ckt.setId(res.getInt("id"));
				ckt.setName(res.getString("name"));
				ckt.setDate(res.getDate("date"));
				ckt.setCountry(res.getString("country"));
				ckt.setBattingStle(res.getString("battingstyle"));
				ckt.setNoc(res.getInt("noc"));
				ckt.setNom(res.getInt("nom"));
				ckt.setRunScore(res.getInt("runs"));
				showPlayers.add(ckt);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new CricketException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new CricketException(e.getMessage());
		}
		return showPlayers;
	}
	@Override
	public Cricket getPlayer(int id) throws CricketException
	{
		Cricket cktm = null;
		try(Connection con = DBUtil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("select * from Cricket where PLAYER_ID =?");
			pstm.setInt(1,id);
			ResultSet res = pstm.executeQuery();
			if(res.next() == false)
			{
				throw new CricketException("No Player Found With Id"+id);
			}
			cktm = new Cricket();
			cktm.setId(res.getInt("id"));
			cktm.setName(res.getString("name"));
			cktm.setDate(res.getDate("date"));
			cktm.setCountry(res.getString("country"));
			cktm.setBattingStle(res.getString("battingstyle"));
			cktm.setNoc(res.getInt("noc"));
			cktm.setNom(res.getInt("nom"));
			cktm.setRunScore(res.getInt("runs"));
		}
		
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new CricketException(e.getMessage());
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
			throw new CricketException(e.getMessage());
		}
		return cktm;
	}
}
package com.capgemini.core.ems.bean;
import java.sql.Date;
public class Cricket 
{
	private int id;
	private String name;	
	private Date date;
	private String country;
	private String battingStle;	
	private int noc;	
	private int nom;
	private int runScore;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getBattingStle() {
		return battingStle;
	}
	public void setBattingStle(String battingStle) {
		this.battingStle = battingStle;
	}
	public int getNoc() {
		return noc;
	}
	public void setNoc(int noc) {
		this.noc = noc;
	}
	public int getNom() {
		return nom;
	}
	public void setNom(int nom) {
		this.nom = nom;
	}
	public int getRunScore() {
		return runScore;
	}
	public void setRunScore(int runScore) {
		this.runScore = runScore;
	}
	public Cricket() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cricket(int id, String name, Date date, String country,
			String battingStle, int noc, int nom, int runScore) {
		super();
		this.id = id;
		this.name = name;
		this.date = date;
		this.country = country;
		this.battingStle = battingStle;
		this.noc = noc;
		this.nom = nom;
		this.runScore = runScore;
	}
}

package com.capgemini.core.ems;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import com.capgemini.core.ems.bean.Cricket;
import com.capgemini.core.ems.service.ICricketService;
import com.capgemini.core.ems.service.CricketServiceImpl;

public class TestCricketService
{
	public static void main(String[] args) throws ParseException
	{
		CricketServiceImpl cricketServiceImpl = new CricketServiceImpl();
	
	Cricket ckt = new Cricket();
	ckt.setName("SachinTendulkar");
	String d = "1973-04-24";
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
	java.util.Date dt = sdf.parse(d);
	java.sql.Date date = new Date(dt.getTime());
	ckt.setDate(date);
	ckt.setCountry("India");
	ckt.setBattingStle("Right Handed Batsman");
	ckt.setNoc(55);
	ckt.setNom(110);
	ckt.setRunScore(19973);
	
	cricketServiceImpl.addPlayers(ckt); 
		
		/*
	employeeService.updatEmployee(employee);*/
		
		/*Cricket crkt = new Cricket();
		crkt.setId(2);
		crkt.setName("SachinTendulkar");
		String d = "1973-04-24";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date dt = sdf.parse(d);
		java.sql.Date date = new Date(dt.getTime());
		crkt.setDate(date);
		crkt.setCountry("India");
		crkt.setBattingStle("Right Handed Batsman");
		crkt.setNoc(56);
		crkt.setNom(110);
		crkt.setRunScore(20000);
		
		cricketServiceImpl.updatePlayers(crkt);*/
	}

}
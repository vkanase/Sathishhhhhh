package com.capgemini.core.ems.view;

import java.sql.Date;	
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.ems.bean.Cricket;
import com.capgemini.core.ems.exception.CricketException;
import com.capgemini.core.ems.service.ICricketService;
import com.capgemini.core.ems.service.CricketServiceImpl;

public class CricketView
{
	private ICricketService icricketService;
	public CricketView()
	{
		icricketService = new CricketServiceImpl();
	}
	public static void main(String[] args)
	{
		CricketView emsUI = new CricketView();
		while(true)
		{
			emsUI.showMenu();
		}
	}

	public void showMenu()
	{	
		Scanner sc = new Scanner(System.in);

		System.out.println("1) Add Player");
		System.out.println("2) Update Player Records");
		System.out.println("3) Show Player Records");
		System.out.println("4) Exit Application");
		System.out.println("Enter Your Choice");
		int choice = sc.nextInt();

		switch (choice)
		{
		case 1:addPlayer(); break;
		case 2:updatePlayers();	break;
		case 3:viewPlayers(); break;
		case 4: System.out.println("Thank You ! Exiting Application....."); break;
		default: System.out.println("Invalid Input");	break;
		}

	}

	private void addPlayer()
	{
		
	Scanner scn = new Scanner(System.in);

	System.out.println("Provide Player Information");
	System.out.println(" Player Name");
	String Name = scn.next();
	System.out.println("Enter Date Of Birth");
	String dob = scn.next();
	System.out.println("Country Playing For");
	String cnt = scn.next();
	System.out.println("Batting Style");
	String bs = scn.next();
	System.out.println("Number Of Centuries");

	int cent = scn.nextInt();
	System.out.println("Number Of Matches Played");

	int nom = scn.nextInt();
	System.out.println("Total Runs Of Career");

	int total = scn.nextInt();

	// Validation OF Input Do Later
	Cricket ckt = new Cricket();
	ckt.setName(Name);

	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
	java.util.Date dt;

	try
	{
		
		dt = sdf.parse(dob);
		java.sql.Date date = new Date(dt.getTime());
		ckt.setDate(date);

		ckt.setCountry(cnt);
		ckt.setBattingStle(bs);
		ckt.setNoc(cent);
		ckt.setNom(nom);
		ckt.setRunScore(total);
		int id = icricketService.addPlayers(ckt);
		System.out.println("Player Added With Player Id "+id);
	}
	catch(CricketException e)
	{
		
		e.printStackTrace();
	}
	
	catch(Exception e)
	{
		
		e.printStackTrace();
	}

	}

	private void getPlayer()
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Retrieving Player Info");
		System.out.println("\n Player Id");
		int id = sc.nextInt();

		try
		{
			Cricket cric = icricketService.getPlayer(id);
			System.out.println("\n Player Information");
			System.out.println("Player Id : "+cric.getId());
			System.out.println("Player Name : "+cric.getName());

			//System.out.println("Player Date Of Birth : "+cric.get);
			System.out.println("Player Country : "+cric.getCountry());
			System.out.println("Batting Style : "+cric.getBattingStle());
			System.out.println("Number Of Centuries : "+cric.getNoc());
			System.out.println("Number Of Matches Played : "+cric.getNom());
			System.out.println("Total Runs : "+cric.getRunScore());
			System.out.println("\n\n");
		}

		catch(CricketException e)
		{
			
			e.printStackTrace();
		}

		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	private void updatePlayers()
	{
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Updating Player Information");
		System.out.println("\n PlayerId");
		int id = sc.nextInt();

		try
		{

			// Attempting to get player assuming id passed is valid

			Cricket cket = icricketService.getPlayer(id);
	//since employee object is retrived update it and send to employeee

			System.out.println("Player Name: "+cket.getName());
			System.out.println("Do You Want To Update Player Name (y/n)");
			char reply = sc.next().toLowerCase().charAt(0);

			if(reply == 'y')
			{
				
				System.out.println("Enter New Name");
				String name = sc.next();
				cket.setName(name);
			}

			System.out.println("Date Of Birth: "+cket.getDate());
			System.out.println("Do You Want To Update Date Of Birth (y/n)");

			reply = sc.next().toLowerCase().charAt(0);
			
			if(reply == 'y')
			{
				
				System.out.println("Enter New Date Of Birth");
				String dob = sc.next();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
				java.util.Date dt = sdf.parse(dob);
				java.sql.Date date = new Date(dt.getTime());
				
				cket.setDate(date);

							}

			System.out.println("Country: "+cket.getCountry());
			System.out.println("Do You Want To Update Country (y/n)");
			reply = sc.next().toLowerCase().charAt(0);

			if(reply == 'y')
			{
				
				System.out.println("Enter New Country");
				String country = sc.next();
				cket.setCountry(country);
			}
			System.out.println("Batting Style: "+cket.getBattingStle());
			System.out.println("Do You Want To Update Batting Style (y/n)");
			reply = sc.next().toLowerCase().charAt(0);
			if(reply == 'y')
			{
				
				System.out.println("Enter New Batting Style");
				String batstyle = sc.next();
				cket.setBattingStle(batstyle);
			}
			System.out.println("Number Of Centuries : "+cket.getNoc());
			System.out.println("Do You Want To Update Number Of Centuries (y/n)");
			reply = sc.next().toLowerCase().charAt(0);

			if(reply == 'y')
			{
				
				System.out.println("Enter New Number Of Centuries");
				int nc = sc.nextInt();
				cket.setNoc(nc);
			}
			System.out.println("Number Of Matches Played : "+cket.getNom());
			System.out.println("Do You Want To Update Number Of Matches Played (y/n)");
			reply = sc.next().toLowerCase().charAt(0);
			if(reply == 'y')
			{
				System.out.println("Enter New Number Of Matches Played");
				int nom = sc.nextInt();
				cket.setNom(nom);
			}
			System.out.println("Total Run Score : "+cket.getRunScore());
			System.out.println("Do You Want To Update Total Run Score (y/n)");
			reply = sc.next().toLowerCase().charAt(0);
			
			if(reply == 'y')
			{
				
				System.out.println("Enter New Total Run Score");
				int tr = sc.nextInt();
				cket.setNoc(tr);
			}

			// Updating Player Details
			icricketService.updatePlayers(cket);
		}
		catch(CricketException e)
		{
			
			e.printStackTrace();
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
		}
	}

	private void viewPlayers()
	{
	
		try
		{
			
			List<Cricket> showPlayers = icricketService.showPlayers();
			Iterator<Cricket> it = showPlayers.iterator();
			// System.out.println("ID \tPlayerName \tDOB \tCountry \tBatting Style \tNo Of Centuries \t no Of Matches Played \tTotal Runs Scored");
			
			while (it.hasNext())
			{		
				Cricket ckt = it.next();
				System.out.println(ckt.getId()+"\t"+ckt.getName()+"\t"+ckt.getCountry()+"\t"+ckt.getBattingStle()+"\t"+ckt.getNoc()+"\t"+ckt.getNom()+"\t"+ckt.getRunScore());
			}
		}
		catch(CricketException e)
		{	
			e.printStackTrace();
		}
		catch(Exception e)
		{	
			e.printStackTrace();
		}
}
}
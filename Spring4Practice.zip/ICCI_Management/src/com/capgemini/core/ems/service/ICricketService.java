package com.capgemini.core.ems.service;

import com.capgemini.core.ems.exception.CricketException;
import java.util.List;
import com.capgemini.core.ems.bean.Cricket;


public interface ICricketService 
{
	public int addPlayers(Cricket ckt) throws CricketException;	
	public void updatePlayers(Cricket ckt) throws CricketException;	
	public List<Cricket> showPlayers() throws CricketException;
	public Cricket getPlayer(int id) throws CricketException;

}

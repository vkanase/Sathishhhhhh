package com.capgemini.core.ems.service;

import java.util.List;

import com.capgemini.core.ems.bean.Cricket;
import com.capgemini.core.ems.exception.CricketException;

public class  CricketServiceImpl implements ICricketService{

	@Override
	public int addPlayers(Cricket ckt) throws CricketException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updatePlayers(Cricket ckt) throws CricketException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Cricket> showPlayers() throws CricketException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cricket getPlayer(int id) throws CricketException {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.DBUtil;

public class BusDAOImpl implements IBusDAO 
{

	static Logger myLogger ;
	
	public BusDAOImpl() 
	{
		PropertyConfigurator.configure("log4j.properties");
		myLogger = Logger.getLogger(BusDAOImpl.class.getName());
	}
	@Override
	public ArrayList<BusBean> retrieveBusDetails() 
	{
		ArrayList<BusBean> buses = new ArrayList<BusBean>() ;
		
		try(Connection con = DBUtil.getConnection())
		{
			Statement stmt = con.createStatement();
			ResultSet res =stmt.executeQuery(" select * from busDetails ");
			
			while(res.next())
			{
				BusBean bus = new BusBean() ;
				bus.setBusId(res.getInt("busId"));
				bus.setBusType(res.getString("busType"));
				bus.setFromStop(res.getString("fromStop"));
				bus.setToStop(res.getString("toStop"));
				bus.setAvailableSeats(res.getInt("availableSeats"));
				bus.setFare(res.getInt("fare"));
				bus.setDateOfJourney(res.getDate("dateOfJourney"));
				
				buses.add(bus);
				myLogger.info(" List Shown Successfully  ");
			}
		}
		catch (SQLException e) 
		{
			//e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new BookingException( e.getMessage() ) ;
		}
		catch (Exception e) 
		{
			//e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new BookingException( e.getMessage() ) ;
		}
		return buses;
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException 
	{
		BusBean bus = null ;
		int generatedId = -1 ;
		try(Connection con = DBUtil.getConnection())
		{
			//Getting Sequence number 
			Statement stm = con.createStatement();
			ResultSet resultSet = stm.executeQuery("select Booking_Id_Seq.nextval from dual");
			
			if(resultSet.next() == false )
				throw new BookingException("Something went wrong whil generating EmployeeId");
			
			int id = resultSet.getInt(1) ;
			String custid = bookingBean.getCustId() ;
			int busid = bookingBean.getBusId() ;
			int seats = bookingBean.getNoOfSeat() ;
			
			//Checking whether the busId provided exists or not
			PreparedStatement pget = con.prepareStatement("select * from busdetails where busId = ? ") ;
			pget.setInt(1, busid);
			
			ResultSet resultGet = pget.executeQuery() ;
			
			if(resultGet.next() == false )
			{
				throw new BookingException(" Bus Id Does Not Exists ") ;
			}
			bus = new BusBean() ;
			
			bus.setBusId(id);
			bus.setBusType(resultGet.getString("busType"));
			bus.setFromStop(resultGet.getString("fromStop"));
			bus.setToStop(resultGet.getString("toStop"));
			bus.setAvailableSeats(resultGet.getInt("availableSeats"));
			bus.setFare(resultGet.getInt("fare"));
			bus.setDateOfJourney(resultGet.getDate("dateOfJourney"));
			
			myLogger.info(" Bus Id Found  "); 
			//Checking the NumberOfSeats Available and performin operation based on it
			if(bus.getAvailableSeats() < seats )
				throw new BookingException(" Sorry No seats are available ") ;
			
			if( seats <= 0 )
				throw new BookingException(" Entered Seat is invalid ") ;
			
			int availableSeats = bus.getAvailableSeats() - seats ;
			
			//if available then first updating 
			PreparedStatement pupdate = con.prepareStatement("update busdetails set availableSeats = ? where busId = ?  ") ;
			
			pupdate.setInt(1, availableSeats);
			pupdate.setInt(2, busid);
			
			pupdate.execute();
			
			myLogger.info("BusDetails Table Updated ");
			
			//Creating a new table and storing bookingDetails
			PreparedStatement pstm = con.prepareStatement("insert into bookingdetails values(?,?,?,?)");
			
			pstm.setInt(1,id);
			pstm.setString(2, custid);
			pstm.setInt(3, busid);
			pstm.setInt(4, seats);
			
			pstm.execute() ;
			generatedId = id ;
			myLogger.info("Booking Id generated ");
		}
		catch( SQLException e)
		{
			//e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new BookingException( e.getMessage() ) ;
		}
		catch (Exception e) 
		{
			//e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new BookingException( e.getMessage() ) ;
		}
		return generatedId;
	}

}

package com.capgemini.core.ems.view;

import java.sql.SQLException;

import java.util.*;

import com.capgemini.core.ems.bean.Employee;

import com.capgemini.core.ems.dao.IEmployeeDAO;

import com.capgemini.core.ems.exceptions.EmployeeException;

import com.capgemini.core.ems.service.EmployeeServiceImpl;

import com.capgemini.core.ems.service.IEmployeeService;

public class EmployeeView

{

	// Loose Coupling

	private IEmployeeService employeeService;

	public EmployeeView()

	{

		employeeService = new EmployeeServiceImpl();

	}

	public static void main(String[] args)

	{

		EmployeeView emsUI = new EmployeeView();

		while(true)
	
		{

			emsUI.showMenu();
		}

	}

	public void showMenu()

	{

		Scanner sc = new Scanner(System.in);

		System.out.println("1) Add Employee");

		System.out.println("2) Get Employee");

		System.out.println("3) Update Employee");

		System.out.println("4) Remove Employee");

		System.out.println("5) View All Employees");

		System.out.println("6) Exit Application");

		System.out.println("Enter Your Choice");

		int choice = sc.nextInt();

		switch (choice)

		{

		case 1:addEmployee(); break;

		case 2:getEmployee();	break;

		case 3:updateEmployee(); break;

		case 4:	removeEmployee(); break;

		case 5:	viewEmployee(); break;

		case 6: System.out.println("Thank You ! Exiting Application....."); break;

		default: System.out.println("Invalid Input");	break;

		}

	}

	private void addEmployee()

	{

		Scanner scn = new Scanner(System.in);

		System.out.println("Provide Employee Enformation");

		System.out.println(" Employee Name");

		String Name = scn.next();

		System.out.println("Employee Department");

		String dept = scn.next();

		System.out.println("Employee Designation");

		String desg = scn.next();

		System.out.println("Employee Salary");

		float salary = scn.nextInt();

		// Validation OF Input Do Later

		Employee employee = new Employee();

		employee.setName(Name);

		employee.setDepartments(dept);

		employee.setDesignation(desg);

		employee.setSalary(salary);

		// Send emp object to database using service

		try

		{

			int id = employeeService.addEmployee(employee);

			System.out.println("Employee added with employee id "+id);

		}

		catch(EmployeeException e)

		{

			e.printStackTrace();

		}

		catch(Exception e)

		{
			e.printStackTrace();
		}

	}
	
	private void getEmployee()
	{

		Scanner sc = new Scanner(System.in);

		System.out.println("Retrieving Employee Info");

		System.out.println("\n Employee Id");

		int id = sc.nextInt();

		try

		{

			Employee employee = employeeService.getEmployee(id);

			System.out.println("\n Employee Information");

			System.out.println("Id "+employee.getId());

			System.out.println("Name "+employee.getName());

			System.out.println("Department "+employee.getDepartments());

			System.out.println("Designation "+employee.getDesignation());

			System.out.println("Salary "+employee.getSalary());

			System.out.println("\n\n");

		}

		catch(EmployeeException e)

		{

			e.printStackTrace();

		}

		catch(Exception e)

		{

			e.printStackTrace();

		}

	}

	private void updateEmployee()
	
	{

		Scanner sc = new Scanner(System.in);

		System.out.println("Updating Employee Information");

		System.out.println("\n EmployeeId");
		
		int id = sc.nextInt();

		try

		{

			// Attempting to get employee assuming id passed is valid

			Employee employee = employeeService.getEmployee(id);

			//since employee object is retrived update it and send to employeee

			System.out.println("Name: "+employee.getName());

			System.out.println("Do You Want To Update Name (y/n)");

			char reply = sc.next().toLowerCase().charAt(0);

			if(reply == 'y')

			{

				System.out.println("Enter New Name");

				String name = sc.next();

				employee.setName(name);

			}

			System.out.println("Department: "+employee.getDepartments());

			System.out.println("Do You Want To Update Department (y/n)");

			reply = sc.next().toLowerCase().charAt(0);

			if(reply == 'y')

			{

				System.out.println("Enter New Deapartment");

				String department = sc.next();

				employee.setDepartments(department);

			}

			System.out.println("Designation: "+employee.getDesignation());

			System.out.println("Do You Want To Update Designation (y/n)");

			reply = sc.next().toLowerCase().charAt(0);

			if(reply == 'y')

			{

				System.out.println("Enter New Designation");

				String designation = sc.next();

				employee.setDesignation(designation);

			}

			System.out.println("Salary: "+employee.getSalary());

			System.out.println("Do You Want To Update Salary (y/n)");

			reply = sc.next().toLowerCase().charAt(0);
	
			if(reply == 'y')

			{

				System.out.println("Enter New Salary");

				float salary = sc.nextFloat();

				employee.setSalary(salary);

			}

			// Updating Employee Details

			employeeService.updatEmployee(employee);

		}

		catch(EmployeeException e)

		{

			e.printStackTrace();

		}

		catch(Exception e)

		{

			e.printStackTrace();

		}

	}

	private void removeEmployee()

	{

		Scanner sc = new Scanner(System.in);

		System.out.println("Remove Employee Details");

		System.out.println("\n Employee Id: ");

		int id = sc.nextInt();

		try

		{

			Employee employee = employeeService.removeEmployee(id);

			System.out.println("\n Employee Details Removed");

			System.out.println("Id "+employee.getId());

			System.out.println("Name "+employee.getName());

			System.out.println("Department "+employee.getDepartments());

			System.out.println("Designation "+employee.getDesignation());

			System.out.println("Salary "+employee.getSalary());

			System.out.println("\n\n");

		}

		catch(EmployeeException e)

		{

			e.printStackTrace();

		}

		catch(Exception e)

		{

			e.printStackTrace();

		}

	}

	private void viewEmployee()

	{

		try

		{

			List<Employee> employees = employeeService.getEmployee();

			Iterator<Employee> it = employees.iterator();

			System.out.println("ID \tName \tDepartment \tDesignation \tSalary");

			while (it.hasNext())

			{

				Employee employee = it.next();

				System.out.println(employee.getId()+"\t"+employee.getName()+"\t"+employee.getDepartments()+"\t"+employee.getDesignation()+"\t"+employee.getSalary());

			}

		}

		catch(EmployeeException e)

		{

			e.printStackTrace();

		}

		catch(Exception e)

		{

			e.printStackTrace();

		}

	}

}
package com.capgemini.core.ems;

import java.util.List;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.service.EmployeeServiceImpl;

public class TestEmployeeService

{
	public static void main(String[] args)
	{

		EmployeeServiceImpl employeeService = new EmployeeServiceImpl();

		// Testing addEmployee Method

		/*Employee employee = new Employee();

		employee.setName("Saikumar");

		employee.setDepartments("Security");

		employee.setDesignation("Administrator");

		employee.setSalary(18000);
	
		employeeService.addEmployee(employee);*/

		//End oF testing Method


		//TEST GET EMPLOYEE METHOD

		/*Employee emp = employeeService.getEmployee(1001);

	System.out.println(emp);*/

	/*Employee employee = new Employee();
	
	employee.setId(1001);

	employee.setName("John");

	employee.setDepartments("IT");

	employee.setDesignation("Java Sr Dev");

	employee.setSalary(36000);

	employeeService.updatEmployee(employee);*/

		//End of test updateEmployee method
		//=================================================================

		Employee emp = employeeService.removeEmployee(1002);

		System.out.println("Employee removed");
		System.out.println(emp);

		//===================================================================

		//Test getEmployee method

		/*List<Employee> emps = employeeService.getEmployee();

		for (Employee employee : emps);
		{
			System.out.println(employee);
		}
		//End of Test getEmployees method
*/
	}

}
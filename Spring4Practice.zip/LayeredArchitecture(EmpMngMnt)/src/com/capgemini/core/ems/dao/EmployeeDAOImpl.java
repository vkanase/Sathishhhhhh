package com.capgemini.core.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.exceptions.EmployeeException;
import com.capgemini.core.ems.util.DBUtil;

public class EmployeeDAOImpl implements IEmployeeDAO

{
	static Logger myLogger;
	
	public EmployeeDAOImpl()
	{
		PropertyConfigurator.configure("log4j.properties");
		myLogger = Logger.getLogger(EmployeeDAOImpl.class.getName());
	}

	@Override

	public int addEmployee(Employee emp) throws EmployeeException
	{
		int generatedId = -1;

		try(Connection con = DBUtil.getConnection()) //Connection will be auto closed
		{
			Statement stm = con.createStatement();

			ResultSet res = stm.executeQuery("Select empIdSeq.nextVal from dual");

			if (res.next() == false)

				throw new EmployeeException("Something went wrong while generating sequence");

			int id = res.getInt(1);
			String name = emp.getName();
			float salary = emp.getSalary();
			String dept = emp.getDepartments();
			String desg = emp.getDesignation();
			
			PreparedStatement pstm = con.prepareStatement("insert into employee values(?,?,?,?,?)");

			pstm.setInt(1, id);

			pstm.setString(2, name);

			pstm.setString(3, dept);

			pstm.setString(4, desg);

			pstm.setFloat(5, salary);

			pstm.execute();

			generatedId = id;
			
			//??????LOGGING??????
			
			myLogger.info("Employee Added Successfully");

		}

		catch(SQLException e)

		{

			e.printStackTrace();
			
			myLogger.error(e.getMessage());

			throw new EmployeeException(e.getMessage());

		}

		catch(Exception e)

		{
			
			throw new EmployeeException(e.getMessage());

		}

		return generatedId;

	}

	@Override

	public Employee getEmployee(int id) throws EmployeeException {

		Employee employee = null;

		try(Connection con = DBUtil.getConnection())

		{

			PreparedStatement pstm = con.prepareStatement("select * from employee where id =?");

			pstm.setInt(1,id);

			ResultSet res = pstm.executeQuery();

			if(res.next() == false)

			{

				throw new EmployeeException("No Employee Found With Id"+id);

			}

			employee = new Employee();

			employee.setId(res.getInt("id"));

			employee.setName(res.getString("name"));

			employee.setDepartments(res.getString("department"));

			employee.setDesignation(res.getString("designation"));

			employee.setSalary(res.getFloat("salary"));
			
			myLogger.info("Employee Details shown Successfully");

		}

		catch(SQLException e)

		{

			e.printStackTrace();
			
			myLogger.error(e.getMessage());

			throw new EmployeeException(e.getMessage());

		}

		catch(Exception e)

		{

			e.printStackTrace();

			throw new EmployeeException(e.getMessage());

		}

		return employee;

	}

	@Override

	public void updateEmployee(Employee employee) throws EmployeeException {

		try(Connection con = DBUtil.getConnection())

		{

			int id = employee.getId();

			String name = employee.getName();

			String dept = employee.getDepartments();
			
			String desg = employee.getDesignation();

			float salary = employee.getSalary();

			PreparedStatement pstm = con.prepareStatement("update employee set name =?,department=?,designation=?,salary=? where id =?");

			pstm.setString(1, name);

			pstm.setString(2, dept);

			pstm.setString(3, desg);

			pstm.setFloat(4, salary);

			pstm.setInt(5, id);

			pstm.executeUpdate();
			
			myLogger.info("Employee update Successfully");

		}

		catch(SQLException e)

		{

			e.printStackTrace();
			
			myLogger.error(e.getMessage());

			throw new EmployeeException(e.getMessage());

		}

		catch(Exception e)

		{

			e.printStackTrace();

			throw new EmployeeException(e.getMessage());

		}

	}

	@Override

	public Employee removeEmployee(int id) throws EmployeeException {
	
	Employee employee = null;
	
	try(Connection con = DBUtil.getConnection() )
	{
		
			employee = getEmployee(id);
			
			if( employee == null)
			{
				throw new EmployeeException("No Employee found with id " + id);
			}
			 PreparedStatement pstm = con.prepareStatement("delete from Employee where id=?");
			
			pstm.setInt(1,id);
			
			pstm.execute();
			
			myLogger.info("Employee remove Successfully");
			
	}
		
			catch (SQLException e)
			{
				e.printStackTrace();
				
				myLogger.error(e.getMessage());
				throw new EmployeeException( e.getMessage() );
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
				throw new EmployeeException( e.getMessage() );
				
			}
		

			return employee;

	}

	@Override

	public List<Employee> getEmployee() throws EmployeeException
	{
		List<Employee> employees = new ArrayList<Employee>();
		
		try(Connection con = DBUtil.getConnection() )
		{
			Statement stm = con.createStatement();
		
			ResultSet res = stm.executeQuery("select * from Employee");
			while( res.next())
			{
				Employee employe = new Employee();
				
				employe.setId(res.getInt("id"));

				employe.setName(res.getString("name"));

				employe.setDepartments(res.getString("department"));

				employe.setDesignation(res.getString("designation"));

				employe.setSalary(res.getFloat("salary"));
			
				employees.add( employe );
				
				myLogger.info("Employee details got Successfully");
			}
		}
	
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new EmployeeException( e.getMessage() );
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException( e.getMessage() );
		}
	

		return employees;

	}

}